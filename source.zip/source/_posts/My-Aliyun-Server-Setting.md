title: 基于阿里云 Ubuntu 的 LAMP 网站搭建及配置完全教程
date: 2016-03-02 14:06:33
tags: 服务器
categories: 术业专攻
---

# 起因

最近老师让我做一个众筹系统，可以在微信公众号上展示运行的。虽然说着简单，但是实现起来却完全不是那么回事，并且我一个做安卓开发的，对服务器和前端完全不懂，这个对我来说一路坎坷，最终上线，这里记录一下我的辛酸历程。

最终效果是在自己的网站服务器网页中运行以下网站：

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/My-Aliyun-Server-Setting/%E8%8A%9D%E9%BA%BB%E4%B9%90-4.JPG?raw=true)

<!-- more -->

# 经过

## 服务器

首先，当然要有一台云服务器，在腾讯云和阿里云当中，学生包的价格分别是1元每月和9.9元每月，这里我选择了阿里云，因为我感觉阿里云用的更多，应该更可靠点（想太多了，我这种小白用户感觉不到差别好么）。在使用阿里云的过程中还是感到了使用阿里云是更简单的，首先实名认证部分只需要绑定支付宝就能完成，学生认证需要输入学号和身份证号和学信网信息一致即可。腾讯云需要本人手持学生证拍照上传，这些略去不提。

## 域名

再者，需要一个域名。当然这个不是必须的，因为只有云服务器ip也能访问服务器上运行的网站。当然我还是买了一个[http://www.fuxuemingzhu.com/](http://www.fuxuemingzhu.com/),这个域名现在是我的博客站点，并不是用来给服务器用，因为我的博客是存储在github.io的，这样写博客的时候还能增加github的contributions……这个域名需要备案和审核，采用的是阿里旗下的万网备案，如实填写，提交各种信息之后有个人工电话审核，接听了之后也只是有个住址信息不完整，帮我完善了下信息，最后阿里送了块幕布，拍照上传之后给工信部备案，总共大概20天左右域名到手。

## 前端和后台

### 系统选择

这两个完成之后，我也就啥都不会了……咳咳，但不能放弃不是，我知道需要前端和服务器配合，本来想按照学姐画的草图用DreamWeaver慢慢画吧，可惜自己水平不是一般的差，完全不会弄。经学姐提醒，可以搜类似网站代码啊，在搜的过程中，我找到了一个RaiseDreams的开源众筹系统！对呀，直接用开源写系统不就完了！看来程序员一般都是想着自己动手，没想到人家已经有免费的直接用就完了。

几经对比，我最终选择了**芝麻乐开源众筹系统**[https://www.zhimale.com/](https://www.zhimale.com/)，开源版本，永久免费，顺便也给人家打一个广告。我感觉这个系统唯一的不足就是帮助文档太少，可能对于我一个新手帮助不够吧。

## 软件安装

我的阿里云服务器运行的是Ubuntu，正好我的电脑也有Ubuntu，所以，就先在本地搭建服务器试用吧。下面进入正式讲解。

首先，需要安装一个Apache，在放狗搜的时候发现了LAMP(Linux-Apache-MySQL-PHP)这个东西。对呀，一次性安装齐全多好！在Ubuntu的官方网站上有教程[https://help.ubuntu.com/community/ApacheMySQLPHP](https://help.ubuntu.com/community/ApacheMySQLPHP)。对我来说只需要一行命令（软件更新速度慢，没用）：

```shell
$ sudo apt-get install lamp-server^
```

不要忘记最后的 ^ 号。

Ubuntu好啊，一行命令就完成了所有的安装，这在Windows下不可想象。中间有一个对MySQL的密码的设置，设置好一定要记住！

![](http://i.imgur.com/6fcMruh.png)

等运行结束之后就全部完成了！

测试Apache，在浏览器输入 127.0.0.1 或者 http://localhost/ ,这个时候不能挂代理。如果出现 It works! 的画面，说明Apache安装成功。

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/My-Aliyun-Server-Setting/2016-03-02%2023-25-59%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE.png?raw=true)

下面检验PHP是否安装成功。在 /var/www/html 文件夹之下新建 testphp.php，打开写入以下内容：

```php
    <?php  
       phpinfo();  
	  ?>  
```

如果用gedit无法编辑保存 testphp.php ，说明该文件为只读模式，请安装vim，并使用以下命令：

```shell
sudo vim /var/www/html/testphp.php
```

在vim模式编辑模式下编写，关闭时要使用强制执行：

```shell
:wq!
```

应该就可以了。如果还是不行可以采用 chmod 改变文章读写权限再试。（我忘记了我用哪种方法成功的了）

然后再在浏览器地址栏输入：http://localhost/testphp.php，出现如图所示内容表示PHP安装成功！

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/My-Aliyun-Server-Setting/2016-03-02%2023-26-23%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE.png?raw=true)

因为芝麻乐系统需要用到php-gd，所以采用以下命令安装。不需要的请不要安装。

```shell
# apt-get install php5-gd
```java

或者

```shell
$ sudo apt-get install php5-gd
```

并且重启狗帕琪。

```shell
# sudo /etc/init.d/apache2 restart
```

至此，所有软件的安装已经结束。还是很简单的吧？

## 软件配置

软件安装过程中会自动生成 /etc/apache2/ 和 /var/www/ 文件夹，这两个基本是我们最重要的设置地方。其中 /etc/apache2/ 是apache的自身设置文件夹， /var/www/ 是要展示的网站的文件夹。其中 /etc/apache2/ 的文件夹目录如下：

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/My-Aliyun-Server-Setting/2016-03-02%2023-41-22%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE.png?raw=true)

可以看到  /var/www/ 只有一个被锁定的只读的文件夹 /html ，这里的文件必须用 sudo 命令打开，vim 编辑退出时使用 :wq! 命令。

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/My-Aliyun-Server-Setting/2016-03-02%2023-47-29%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE.png?raw=true)

下面设置自己的服务站点，并让其能在自己的网页上显示出来。

在 /var/www/ 文件夹下新建www.test.net的文件夹，并将开源网站所有代码和文件放入到其中，效果如图。

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/My-Aliyun-Server-Setting/2016-03-02%2023-51-29%E5%B1%8F%E5%B9%95%E6%88%AA%E5%9B%BE.png?raw=true)

下面修改apache的路径指向www.test.net的文件夹。使用以下命令进行编辑。

```shell
$ sudo vim /etc/apache2/sites-available/000-default.conf
```

将其中的ServerName取消注释，并将DocumentRoot修改为 /var/www/www.test.net，并使用 :wq! 命令保存关闭vim.

重启Apache:

```shell
# sudo /etc/init.d/apache2 restart
```

如果没有问题的话就已经进入了芝麻乐重酬平台开源系统的安装界面了。按照芝麻乐的官方教程来做，应该很快就能安装成功。

官方教程网址：[https://www.zhimale.com/News/show/id/8.html](https://www.zhimale.com/News/show/id/8.html)

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/My-Aliyun-Server-Setting/%E8%8A%9D%E9%BA%BB%E4%B9%90-2.png?raw=true)

至此，芝麻乐开源众筹系统已经在本地的Ubuntu上安装成功。

### 服务器配置

本地安装一切顺利，可是没想到服务器上安装同样的东西却状况连连。

#### 怎么连接服务器？

采用阿里云推荐方式，Windows下安装盘putty，使用这个来与运行在阿里云上的服务器进行通信和命令传输。参考[www.putty.org](www.putty.org)

#### 怎么把文件传送到服务器？

经过一番搜索，我采用在服务器搭建ftp系统，然后用ftp传送的方式。这里使用 vsftpd，安装和配置过程略去不讲，参考[//TODO](http://blog.csdn.net/dongtingzhizi/article/details/12028627) 和 [http://jingyan.baidu.com/article/67508eb4d6c4fd9ccb1ce470.html](http://jingyan.baidu.com/article/67508eb4d6c4fd9ccb1ce470.html)。

这个配置是挺麻烦的，因为服务器上的文件是可以ftp给大家看的，如果没有做到充分地保障的话，服务器可能被大家搞得一塌糊涂，需要花点功夫好好折腾一下。

Windows上安装FileZilla，这样可以连接到服务器ip，注意端口为21.

将Windows下的芝麻乐平台代码进行上传，如果出现530错误，说明vsftpd设置的文件夹没有写入权限，需要使用以下命令改变文件夹的写入权限。

```shell
# sudo chmod 755 /home/sftp/
```

上传成功之后进行文件夹复制，使用以下命令。

```shell
# sudo cp /home/sft/ /var/www
```

文件复制参考：[http://zhidao.baidu.com/question/63755445.html](http://zhidao.baidu.com/question/63755445.html "ubuntu 拷贝 文件夹 到 另外一个文件家下，如何些shell命令")

如果失败的话，同样是因为文件夹权限的问题，记得使用chmod改变/var/www/文件夹的写入权限。

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/My-Aliyun-Server-Setting/%E8%8A%9D%E9%BA%BB%E4%B9%90-1.png?raw=true)

这样之后，就成功把系统放入到了要配置的目标文件夹。下面配置Apache指向这里的文件夹。

```shell
$ sudo vim /etc/apache2/sites-available/000-default.conf
```

将其中的ServerName取消注释，并将DocumentRoot修改为 /var/www/sftp，并使用 :wq! 命令保存关闭vim.

注意：上面的这些过程中如果出现错误一般就是读写权限的问题，出现错误之后注意修改文件夹的写入权限。

重启Apache，理论上已经可以用了，浏览器直接输入服务器的网址就行。

#### 遇到问题怎么办？

这时候如果出现关于ServerName的警告：

> Restarting web server apache2

> apache2: Could not reliably determine the server's fully qualified domain name, using 127.0.1.1 for ServerName

那么请在 /etc/apache2/apache2.conf 中添加：

```shell
ServerName localhost
```

重启Apache，这个警告就会消失。

可是我的服务器给我了500的错误，这个是怎么回事呢？为什么本地运行没出现这个问题？而且没有显示错误日志。

本以为是PHP安装没成功，但是搜索一番之后，受到启发，可以开启PHP的错误提示，然后进行分析。开启PHP错误提示的方法参考：[http://tsov.net/open-ubuntu-php-error/](http://tsov.net/open-ubuntu-php-error/)

```shell
sudo chmod 777 /etc/php5/apache2/php.ini

sudo vim /etc/php5/apache2/php.ini
```

搜索并修改下行，把Off值改成On


	display_errors = Off

这就完成了，重启Apache。

这次服务器网页上会出现错误提示了，如下：

	Unknown: failed to open stream

经过搜索，参考以下网页[http://stackoverflow.com/questions/5326531/php-warning-unknown-failed-to-open-stream](http://stackoverflow.com/questions/5326531/php-warning-unknown-failed-to-open-stream)，我推断是因为文件夹的读写权限导致。这个很奇怪，为什么读权限的文件夹不能在Apache上？这个我没有深入研究。那么下面的问题是修改 /var/www/ 文件夹下的文件的写入权限，把文件夹的用户切换到我的用户名root。

```shell
cd /var/www

sudo chown www-data:www-data * -R

sudo usermod -a -G www-data root
```

重启Apache。

这次已经出现了芝麻乐的开源系统安装引导，按指导进行安装就能成功啦！

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/My-Aliyun-Server-Setting/%E8%8A%9D%E9%BA%BB%E4%B9%90-3.png?raw=true)

## 结语

至此安装已经完全成功，中途遇到了很多问题，最终都在强大的Google的帮助下解决。上面的文章虽然写到的遇到的问题的内容篇幅不多，但是却花了我两天的时间。中途学到了很多东西，也让我对服务器的使用更加熟练。

另外，我在遇到问题的时候并没有完全当时截图，后来写文章时有参考别人，另外命令不保证完全正确。

## 参考文献

用到的文章在文章当中基本上都写了，在此表示感谢。

部分图片来自网络。