title: Java读书笔记
date: 2016-03-29 16:34:25
tags: [java,读书,经验分享]
categories: 术业专攻
---
# Java必须知道的300个问题

这本书是在图书馆随便逛的时候找到的书。花了一下午看完了，感觉有用的地方不是很多，大部分都是些概念，并没有太大用途。里边有些东西还是可以看一看的，总结如下。

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/java-read-book-notes/300-questions.jpg?raw=true)

当前写完这本书笔记的时间是：2016/3/29 19:52:26 

<!-- more -->

## Java语言基础

### 1.表达式3-2.6==0.4的值？

答：false。 这是有基本数据类型浮点数计算的不精确性造成的。

3-2.6=0.39999999999999999999..

可以用BigDecimal进行浮点数精确计算。

### 2.&和&&两个运算符的区别？

答：& 位与，&& 逻辑与。

### 3.不适用循环和条件语句如何求1+2+3+...+n？

答：函数递归调用。

### 4.能正确编译"short s=1;s=s+1;"吗？

答：不能。类型不匹配。可：s+=1；

### 5. += 计算结果一定正确吗？

答：不。可能溢出。

### 6.两个整数相乘结果一定正确吗？

不。

long num=2147483648.超出int范围，编译错误。

long num=214748364*10 结果为-10.int溢出。

long num=2147483648L*10 正确。

### 7.如何跳出多重嵌套循环？
```java
label:
fori(){
	break label;
}
```
### 8.存储相同数据量的一维数组和二维数组所占内存是否相同？

二维数组远远大于以为数组。？？？

### 9.只能通过构造方法构造对象吗？

不是。

```java
Calendar c=Clalendar.getInstance();
```

### 10.接口和抽象类的区别？

1、抽象类可以提供成员的实现细节，而接口不能。数级抽象时如果要求提供成员的实现细节，可选抽象类。

2、如果涉及抽象时选择抽象类，在以后的版本中可以随意为抽象类添加新成员。而接口只有修改现有代码才能添加新成员。

3.一个类可以实现多个接口，但是能继承一个抽象类。如果要实现类似多重继承的效果，选接口。

两者相似，某些功能可以互换。但理念不同，抽象类用于继承，表示is-a；接口用于实现，表示like-a。

### 11.clone()方法的使用？

1.浅克隆

被克隆的对象各个属性都是基本类型，而不是引用类型，如果存在引用类型的属性，则需要进行深克隆。

2.深克隆

如果需要克隆的饿对象的域包含引用类型，则需要使用深克隆；
繁殖，可以直接使用Object类的clone()方法进行浅克隆。

### 12.两种方式可以实现深克隆，效率如何？

1.序列化，效率很差。

2.榆次克隆各个可变的引用类型域的方式。

### 13.在内部类中调用外部类同名的成员？

在内部类中调用内容类的x： this.x=...

在内部类调用外部类的X: TheSamName.this.x=...

### 14.反射？

额，不会。。

## 字符串和包装类

### 15.自动装包、拆包？

基本数据类型自动转换成类.集合中不能存储基本数据类型。

```java
int a=3;

arraylist.add(a);
```

### 16.String可以被继承么？

不可以。final修饰的类不能被继承。

### 17.各种进制的转换

```java
Integer.parseInt("101001010",2);二进制转int
Integer.toBinaryString(int i);
...
```

## Java集合类框架

### 18.数组 和 集合的转换

```java
List<Integer> list=new Arrays.asList(1,2,3,4,5);

Interger[] array=list.toArray(new Integer[]{});
```

### 19.Collection 和 Collections 的区别？

Collection是集合类的派生接口。是Java集合类的基础。

Collections是为集合类定义的工具类，包含了一些查找排序的方法，非常实用。

### 20.获得Map中的全部键？

Map接口中的keySet()方法

```java
Set<K> keySet()

Set<Integer> keySet=map.keySet();
```

然后通过键获得值。

### 21.获得Map中的全部值？

```java
values()

Collection<V> values()

Collection<Integer> values=map.values();
```

### 22.获得Map中的全部键值对？

```java
Set<Map.Entry<K,V>> entrySet()
```

## 异常处理

### 23.throw和throws区别

throws是方法里的声明要抛出什么异常

throw是抛出具体异常

## I/O

### 24.对象流？

DataInput DataOutput 可以吧对象写入到磁盘中

但是读写的对象必须实现了Serializable接口。
