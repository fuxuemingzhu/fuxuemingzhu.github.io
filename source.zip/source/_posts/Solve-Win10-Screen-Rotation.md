title: Win8/Win10 Ctrl+Alt+方向键 屏幕显示翻转解决办法
date: 2016-03-03 20:28:35
tags: [Windows,经验分享]
categories: 术业专攻
---

## 状况

Win10系统下，在Android Studio中使用快捷键 **Ctrl + Alt + ↓** 复制代码段的时候神奇的情况出现了，屏幕显示倒转了，我也只能是一脸懵逼，Win7下没有这个问题。经验判断是AS的快捷键和Win10快捷键冲突了。回复正常的屏幕的方向的方法是快捷键 **Ctrl + Alt + ↑** ，下面解决这个冲突。

![](https://raw.githubusercontent.com/fuxuemingzhu/fuxuemingzhu.github.io/master/images/Solve-Win10-Screen-Rotation/%E6%87%B5%E9%80%BC.jpg)

<!-- more -->

## 解决方案

首先 按 **Ctrl + Alt + F12** 进入以下管理界面：

![](https://raw.githubusercontent.com/fuxuemingzhu/fuxuemingzhu.github.io/master/images/Solve-Win10-Screen-Rotation/1.png)

点击选项和支持，在以下界面点击禁用快捷键。

![](https://raw.githubusercontent.com/fuxuemingzhu/fuxuemingzhu.github.io/master/images/Solve-Win10-Screen-Rotation/2.png)

应用退出即可。

![](https://raw.githubusercontent.com/fuxuemingzhu/fuxuemingzhu.github.io/master/images/Solve-Win10-Screen-Rotation/3.png)

这次再按 **Ctrl + Alt + ↓** ，发现屏幕不再旋转，问题解决。