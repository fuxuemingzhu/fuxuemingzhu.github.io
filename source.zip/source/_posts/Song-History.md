title: 最近感动到哭的一首歌《History》
date: 2016-03-01 19:23:11
tags: 音乐
categories: 生活随笔
---

![](http://i.imgur.com/wAjQx5b.jpg)

第一次在油管上听到小破团的《History》的时候，我并没有太在意，只是感觉很好听。当某次看到这个MV的时候，看到四个人朴素的着装站在一面破旧的砖墙前毫无拘束、任性自由的手舞足蹈，画面中穿插着他们从出道来的成长和一起玩耍的黑白画面。这画面太朴素，但从刚出道时的五个小嫩肉到现在的四人组合，这转折让我怎么也不能平静下来。

<!-- more -->

想必大家都是以一首《What makes you beutiful》开始了解的One Direction，从开始听他的歌到不久前大概一年多的时间里，我只喜欢他们的这一首歌。除此之外对他们的了解只限于哈卷和泰勒情感故事，我并不喜欢哈卷，总是感觉他有点颐指气使，处事傲慢。

上一次注意到关于他们的新闻就是渣Zayn离团事件，这可能是关注欧美圈以来歌手里面比较震惊的事件。和大家一样，我不能想象出来少了一个歌手的乐队怎么继续走下去，他们将以什么的面貌继续出场，甚至怀疑他们是否从此一蹶不振、土崩瓦解。

看来我还是错了，小破团的最新专辑一改之前颓靡之风，歌词积极向上，乐调欢快顺口，开始走上了正能量的道路，因此我也更加喜欢他们最近的作品，如《Drag me down》，《Perfect》等。

![](http://i.imgur.com/XuOzkYS.jpg)

《History》正是把我们对这些的感慨化为乐符，回忆起自己以前的朝夕相处的朋友，他们唱到：


> You and me, got a whole lot of history

> We could be the greatest team that the world has ever seen

> You and me, got a whole lot of history

> So don't let it go, we can make some more, we can live forever

他们向全世界唱出了“请不要离开，我们可以成为最好的组合”的时候，有谁不为他们感动到cry呢。

看到他们当初那么青涩，现在的他们已经对整个现场把握的很到位，他们完全都是在放松的玩耍的状态录制MV，感觉他们已经完全习惯于彼此，融为一个整体了。

盛筵难再啊，四人组合唱出了对以前的兄弟的最真挚的表述，再想起以后的自己和我现在熟悉的这些人也最终是会像他们一样的分开，或许我们还能在一起高唱最喜欢的歌？



> Baby don't you know

> 難道你不知道嗎？

> Baby don't you know

> 難道你不知道

> We can live forever

> 我們可以成為永恆

附上油管链接：[https://www.youtube.com/watch?v=yjmp8CoZBIo](https://www.youtube.com/watch?v=yjmp8CoZBIo)