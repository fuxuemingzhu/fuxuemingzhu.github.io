title: 微信精选，每日精选微信优质文章App开发总结
date: 2016-03-17 21:43:32
tags: [Android,经验分享]
categories: 术业专攻
---

## 缘起

微信精选的App开发来源是在聚合数据上看到了有免费的微信精选的数据接口，无限调用。相对于其他的诸如违章查询，医药查询，NBA赛事等等，我感觉还是微信文章精选这个数据接口离我最近，所以想着拿着个数据源练练手。

另外，有个笑话的接口我感觉还挺有意思的，也做成了一个APP，已经上线，可以在我的上一篇文章中看到详细的介绍。

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/WeChoice/ic_launcher_192.png?raw=true)

<!-- more -->

## 雏形

在这个App进入大家视野之前我已经做了一版，是用到了各方的库拼凑而成的，也实现了基本的列表、阅读文章的功能，里边的下拉刷新，加载更多，进度条都是用的不同方的，整体的结构感和风格太差。这也是我不是很满意的地方。

但就是在做上一个App——找乐，我发现了一个新的可以反复复用，结构明显，易于使用，风格统一的框架——Beam([Beam](https://github.com/Jude95/Beam))。这个MVP结构的结构框架已经集成好了列表界面的刷新、加载更多、错误提示、进度提示等等，这用起来也太方便了！所以我花了一天的时间对之前写的应用进行了重构，删除了不少代码，并且使用了MVP模式的整个App结构看起来非常舒服。以后如果自己做App就用这个框架（求推荐其他的框架），开发效率大大提升。

这个是App重构后的样子：

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/WeChoice/%E5%B1%95%E7%A4%BA1.png?raw=true)

本项目已经开源：[https://github.com/fuxuemingzhu/WeChoice](https://github.com/fuxuemingzhu/WeChoice)，欢迎Star和Fork。

## 开发

这种类似新闻客户端的开发经验较少，在看了其他的客户端之后发现基本都差不多，那我就从简开发吧。

### 框架

对于Beam框架，搭配上EasyRecyclerView，这样的MVP架构对生命周期的管理特别好，比如刷新、加载、错误提示、进度条等等，大家试用了这个微信精选App后可能也会有这样的感受，所有的东西展示不是那么突兀，显得很连贯，这要感谢框架的作者的贡献，也对大家推荐这个框架[Beam](https://github.com/Jude95/Beam).

估计这个框架可能节省了我开发项目的2/3的时间。

### 数据

前文已经说了，使用的聚合数据的微信精选的接口[https://www.juhe.cn/docs/api/id/147](https://www.juhe.cn/docs/api/id/147)，其实对于这个接口不是非常满意，因为功能有点少嘛。但是无限制调用这个还是可以拿来练手的。

我开源的数据中没有把聚合数据的AppKey给公开，如果需要基于本项目改造的，请**自行申请APPKey**.

### 设计

本来打算用CardView来实现卡片效果，但是发现CardView会自动设置为阴影效果和圆边，这样就要求数据之间要有间隙。但在Google的Material Design中，我的这种想法是不推荐的。

下图中，左边为推荐，右边不推荐：

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/WeChoice/cards.png?raw=true)

理由是：

> Don't.

> The use of cards here distracts the user from being able to quickly scan. These list items are also not dismissable, so having them on separate cards is confusing.

好吧，在我多次希望能通过调节Card之间的间隙达到比较满意的推荐效果时，发现做不到，好吧，那只有乖乖用普通的FramLayout了。效果大家也都看到了。

### 技术亮点

**双队列实现数据加载不重复**

在找乐App中没有做这个功能，就是在下拉刷新的时候可以不停地更新数据。大家做开发的都明白，数据是按页返回的，一般下拉的时候默认的就请求了第一页的数据，因此数据基本都是原来的数据。在微信精选这个App中，我用了双队列——下拉刷新队列和上拉加载更多队列，来实现了这个记载数据不重复的问题。

道理很简单：记录下来已经加载的页数，下次想服务器请求的时候不去请求已经加载过的页，这样就可以实现数据不重复。

至于用队列，是因为聚合数据的数据页数有限（只有25页），我把下拉刷新队列存放的页数设置成了10，也就是说在下拉10次之内不会出现重复数据，第11次刷新的时候把对第一次放入队列的数字出列。上拉加载更多的页数设置为25，在25次上拉之后清空队列。

每次新数据的进入是使用的随机数的方式。嗯。

具体实现如下：
```java
private int morePages = 1;
final int QUEUE_SIZE = 10;//队列大小
//手写队列用来存储已经加载过的文章页数
Queue<Integer> refreshQueue = new LinkedList<>();
Queue<Integer> moreQueue = new LinkedList<>();

int page = 1;
@Override
public void onRefresh() {
super.onRefresh();

if (refreshQueue.size() == QUEUE_SIZE) {
    refreshQueue.poll();
}
refreshQueue.offer(page);
moreQueue.clear();
moreQueue.offer(page);

ChoiceModel.getInstance().getChoice(page, new DataCallback() {
    @Override
    public void success(String info, ChoicePage data) {
	getAdapter().clear();
	getAdapter().addAll(data.getContentlist());
	while (refreshQueue.contains(page)) {
	    page = (int) Math.ceil(Math.random() * 25);
	}
	JUtils.Log("refreshQueue", refreshQueue.toString());
    }

    @Override
    public void error(String errorInfo) {
	getView().showError(new Throwable(errorInfo));
    }
});

}

@Override
public void onLoadMore() {
super.onLoadMore();
while (moreQueue.contains(morePages)) {
    morePages = (int) Math.ceil(Math.random() * 25);
}
if (moreQueue.size() == 25) {
    moreQueue.clear();
    moreQueue.offer(page);
}
moreQueue.offer(morePages);
JUtils.Log("moreQueue", moreQueue.toString());


ChoiceModel.getInstance().getChoice(morePages, new DataCallback() {
    @Override
    public void success(String info, ChoicePage data) {
	getAdapter().addAll(data.getContentlist());
    }

    @Override
    public void error(String errorInfo) {
	getView().showError(new Throwable(errorInfo));
    }
});
}
```

**解决WebView选择框弹出时将ToolBar下推问题**

长按WebView中的文字，会弹出上下文选项，ToolBar会下推。如下图1。

参考了狐狸大神的文章：[解决ToolBar在显示上下文菜单中被推下的问题](http://icyfox.com/2015/03/24/toolbar-and-contextual-action-bar/)

只是在AppTheme style中一行代码的事情：

```xml
<item name="windowActionModeOverlay">true</item>
```

或者如下，根据安卓版本而不同：

```xml
<item name="android:windowActionModeOverlay">true</item>
```

效果如下：

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/WeChoice/%E5%B1%95%E7%A4%BA3.png?raw=true)


### 缺陷

其实不满意的地方挺多的= =，这里主要说一下最不满意的地方，就是WebView这一块。加载文章详情的时候，这个原生WebView很不好用！

1. 很差的进度提醒机制
2. 很差的错误识别与处理机制
3. 很差的数据重新记载体验
4. 无法查看大图

感觉每个都很影响体验，目前的实现非常不爽，代码看了代码之后就会知道我为了识别网页错误在多少地方做了监听处理。而且查看大图和下载也没有实现。

希望大家能给出好的WebView的封装框架，因为我一直没找到这方面的开源项目。

同时缺少了分享模块、搜索模块。

### 截图

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/WeChoice/%E5%B1%95%E7%A4%BA2.png?raw=true)

### 下载

- 小米应用商店
- 应用宝
- 豌豆荚
- Fir.im：[http://fir.im/wechoice](http://fir.im/wechoice)

二维码：

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/WeChoice/fir.png?raw=true)

（暂时只能通过Fir，其他的应用商店还在审核，应用宝审核已被打回两次，你懂。）

## 总结

花了一整天对项目进行了重构，优化了一天处理界面、开源和本博客，时间其实还是没用很多的。再次感谢这个框架Beam，真是程序员的福音。

这个项目本来不打算开源的，但是我感觉用了框架之后自己写的东西就很少了，干脆开源。

**但是本作者保留一切商业化的权利。**

**一切基于本项目的修改都必须开源，并且采用相同的开源协议。**

好了，本项目的地址是：[https://github.com/fuxuemingzhu/WeChoice](https://github.com/fuxuemingzhu/WeChoice)，欢迎Star和Fork。