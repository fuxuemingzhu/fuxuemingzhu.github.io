title: Hello LaTeX
date: 2015-12-18 16:50:05
tags: LaTeX
categories: 术业专攻
---

## 起源

最早听说LaTeX是在做数据挖掘的熊辉老师公开课上，当时他说他看别人投过来的论文时，如果用Word写的，直接Pass，用"LaTeX"的才看。当时没有字幕，我愣是听了好几遍才根据发音把"LaTeX"这个词给拼了出来，搜索了相关资料。后来了解到了中国化之后的CTeX。

自从接触到这个词之后才感觉周围到处都是在讲LaTeX（可能是我之前没注意），学校里也有大神用LaTeX写毕设论文，恰巧我又在看美赛建模的一些经验，里面也有人提到了LaTeX，总之，LaTeX对我来说越来越具有吸引力。

![](http://i.imgur.com/OSVpy6f.png)

<!-- more -->

## 经过

当然首先是下载安装了。这本应该是最简单的一步，结果让我整了好久才弄成功。

对于CTeX，在其官方社区[http://www.ctex.org/HomePage](http://www.ctex.org/HomePage)上给了百度网盘的下载地址。是我不小心，把所有的历史版本的CTeX都下载了下来，当然我发现下的不对，暂停了下载，只下载了最新的CTeX2.9。

讲一讲在安装时遇到的问题。

第一个，CTeX安装会覆盖系统环境变量，这个太坑爹，还好我提前做了备份。

第二个问题，第一次安装之后发现不好使，具体表现是WinEdt打开新建文件编译有问题，命令行的提示是“系统找不到相关文件”。我以为是下载的时候没现在完整（文件夹里还有.download文件），于是把CTeX2.9的Full版本给卸载重装。仍然同样问题。以为是没有字体库，安装上了，仍然不好使。卸载了重新装基本版本。仍然不好使。这个时候我就不淡定了，以为是CTeX的锅，打算装原版LaTex，反正美赛建模于是用纯英文写作。百度呀、Google呀、论坛呀都没搜到相关问题的答案，我感觉是我电脑的问题，或者我下载了盗版，我不会是唯一一出现这个问题的吧。

今天下午水论坛，发现一个人也是请教CTeX的问题，当然问题和我的问题不一样，但帖子底下有条回复是让楼主去CTeX的社区去问。这就提醒我，在一些技术性比较强的场合，自己专门的社区很可能比百度后者Google上其他人的经验内容要丰富。在CTeX社区搜索真发现了类似问题的帖子。逛了两个帖子之后找到了解决方案。

![](http://i.imgur.com/FVookeu.jpg)

我试了一下，再次打开WinEdt就完全正常了！

这个莫名其妙的错误困扰了我两三天。另外这个其实也发现是我们论坛的好哇，说不定哪个贴子就可以启发自己的思路找到正确结果。![](http://bbs.byr.cn/img/ubb/ema/9.gif)

使用方法：

![](http://i.imgur.com/PHnINJg.jpg)

我用的是XeLaTeX编译。然后点击放大镜查看pdf.

上几个小栗子。

```latex
\documentclass{article} 
  \author{My Name} 
  \title{The Title} 
\begin{document} 
  \maketitle 
  hello, world % This is comment 
\end{document} 
```

运行结果：

![](http://i.imgur.com/7RkGe3A.jpg)

挺漂亮的吧。

中文示例：

```latex
\documentclass{ctexart}
\begin{document}
你好，世界
\end{document} 
```

结果：

![](http://i.imgur.com/ZHbMYWF.jpg)

图片示例：

```latex
\documentclass{article}
  \usepackage{graphicx}
\begin{document}
    
    taylor.jpg

  \includegraphics[width=4.00in,height=4.00in]{taylor.jpg}
\end{document}
```latex

结果：

![](http://i.imgur.com/kSSjIpV.jpg)

## 结语

LaTeX虽然不是一项必须的技能，但是我感觉是一个写文章的很好的方式。当然Word的所见即所得令人爱不释手，但是对于专业论文的书写，LaTeX有它天生的优势。新技能，get。

## 参考文献

CSDN:[LaTeX新人教程，30分钟从完全陌生到基本入门](http://blog.csdn.net/perfumekristy/article/details/8515272)