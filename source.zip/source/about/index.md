title: 留言板 & 关于我
date: 2015-12-08 20:22:16
---

## 关于我

喜欢折腾，Android开发进阶中，希望写出一个好的App.

严重歌曲依赖患者，写代码时没有插上耳塞听点什么感觉少些啥。

闲暇时间会看个电影刷刷美剧。

如果有好玩的游戏和有意思的设计请让我知道。

谷歌严重依赖症。

网名来自“苍山负雪，明烛天南”，唉，程序猿应该有个高大上的英文名字的。

## 专注于 Android 开发

GitHub 地址: [https://github.com/fuxuemingzhu](https://github.com/fuxuemingzhu)

CSDN 地址：[http://blog.csdn.net/fuxuemingzhu](http://blog.csdn.net/fuxuemingzhu)

Email: fuxuemingzhu#163.com，请把#替换成@

## 项目

### 找乐

一款纯粹的笑话App，24小时更新段子和笑话图，支持查看大图和下载图片及复制文字。

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/FindJoy/hecheng.png?raw=true)

应用宝下载：
![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/FindJoy/yingyongbao.png?raw=true)

豌豆荚下载：
![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/FindJoy/wandoujia.png?raw=true)

项目主要难点和开发总结：[http://www.fuxuemingzhu.com/2016/03/15/Find-Joy/](http://www.fuxuemingzhu.com/2016/03/15/Find-Joy/)

### 微信精选

微信精选，每天24小时精选微信优质文章，科技、娱乐、八卦、职场、人生，这款应用里面应有尽有。

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/WeChoice/%E5%B1%95%E7%A4%BA1.png?raw=true)

技术亮点： **使用双队列实现数据加载不重复**

Fir.im下载：[http://fir.im/wechoice](http://fir.im/wechoice)

二维码：

![](https://github.com/fuxuemingzhu/fuxuemingzhu.github.io/blob/master/images/WeChoice/fir.png?raw=true)

项目主要难点和开发总结：[http://www.fuxuemingzhu.com/2016/03/17/WeChoice/](http://www.fuxuemingzhu.com/2016/03/17/WeChoice/)