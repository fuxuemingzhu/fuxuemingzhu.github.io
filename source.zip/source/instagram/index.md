---
layout: post
slug: "instagram"
title: "相册"
noDate: "true"
---

<div class="instagram" data-client-id="d8a1405fbe604a8f882d763596f327e8" data-user-id="1605026490">
    <a href="https://www.instagram.com/fuxuemingzhu/" target="_blank" class="open-ins">图片来自instagram，正在加载中…</a>
</div>
<script src="/js/jquery.lazyload.js"></script>
<script src="/js/instagram.js"></script>
<script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.8.0.js"></script>